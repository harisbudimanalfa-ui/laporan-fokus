const crypto = require('crypto');

const json = (status, body) => ({ statusCode: status, headers: {'Content-Type':'application/json','Access-Control-Allow-Origin':'*'}, body: JSON.stringify(body) });
const norm = v => String(v ?? '').trim().toUpperCase();
const hash = v => crypto.createHash('sha256').update(String(v ?? '')).digest('hex');

async function supabase(path, options={}) {
  const base = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_SECRET_KEY;
  if(!base || !key) throw new Error('Konfigurasi Supabase di Netlify belum lengkap.');
  const r = await fetch(base.replace(/\/$/,'') + '/rest/v1/' + path, {
    ...options,
    headers: {'apikey':key,'Authorization':`Bearer ${key}`,'Content-Type':'application/json','Prefer':'return=representation',...(options.headers||{})}
  });
  const text = await r.text(); let data; try{data=JSON.parse(text)}catch{data=text}
  if(!r.ok) throw new Error(typeof data==='string' ? data : (data.message || data.hint || 'Supabase request gagal.'));
  return data;
}
function adminOk(key){ return String(key||'') === String(process.env.NAFPRO_ADMIN_KEY||''); }

exports.handler = async event => {
  if(event.httpMethod==='OPTIONS') return json(204,{});
  if(event.httpMethod!=='POST') return json(405,{ok:false,message:'Method tidak diizinkan.'});
  let body={}; try{body=JSON.parse(event.body||'{}')}catch{return json(400,{ok:false,message:'JSON tidak valid.'})}
  try{
    const action=body.action;
    if(action==='login'){
      const store=norm(body.store), nik=String(body.nik||'').trim(), password=String(body.password||'');
      if(!store||!nik||!password) return json(400,{ok:false,message:'Kode toko, NIK, dan password wajib diisi.'});
      const shops=await supabase(`kode_toko?select=kode,nama_toko,aktif&kode=eq.${encodeURIComponent(store)}&aktif=eq.true`);
      if(!Array.isArray(shops)||!shops.length) return json(401,{ok:false,message:'Kode toko tidak terdaftar.'});
      const users=await supabase(`naf_users?select=id,store,nik,name,role,countdown_minutes,active,password_hash&store=eq.${encodeURIComponent(store)}&nik=eq.${encodeURIComponent(nik)}&active=eq.true&limit=1`);
      const u=users?.[0];
      if(!u) return json(401,{ok:false,message:'NIK atau password salah.'});
      const supplied=hash(password), stored=String(u.password_hash||'').trim();
      if(stored!==supplied && stored!==password) return json(401,{ok:false,message:'NIK atau password salah.'});
      return json(200,{ok:true,user:{id:u.id,store:norm(u.store||store),nik:u.nik,name:u.name,role:u.role,countdown_minutes:Number(u.countdown_minutes)||60},toko:shops[0]});
    }
    if(action==='admin_list_users'){
      if(!adminOk(body.adminKey)) return json(403,{ok:false,message:'Kunci Admin salah.'});
      const users=await supabase('naf_users?select=id,store,nik,name,role,countdown_minutes,active&order=store.asc,nik.asc');
      return json(200,{ok:true,users});
    }
    if(action==='admin_add_user'){
      if(!adminOk(body.adminKey)) return json(403,{ok:false,message:'Kunci Admin salah.'});
      const store=norm(body.store), nik=String(body.nik||'').trim(), name=String(body.name||'User').trim()||'User', password=String(body.password||''), minutes=Number(body.countdownMinutes);
      if(!store||!nik||password.length<1||!Number.isFinite(minutes)||minutes<1) return json(400,{ok:false,message:'Data user belum lengkap.'});
      const shops=await supabase(`kode_toko?select=kode&kode=eq.${encodeURIComponent(store)}&aktif=eq.true`);
      if(!shops.length) return json(400,{ok:false,message:'Kode toko belum ada di tabel kode_toko atau tidak aktif.'});
      const existing=await supabase(`naf_users?select=id&store=eq.${encodeURIComponent(store)}&nik=eq.${encodeURIComponent(nik)}&limit=1`);
      if(existing.length) return json(409,{ok:false,message:'Kombinasi kode toko dan NIK sudah terdaftar.'});
      const created=await supabase('naf_users',{method:'POST',body:JSON.stringify({store,nik,name,role:'user',password_hash:hash(password),countdown_minutes:Math.floor(minutes),active:true})});
      return json(200,{ok:true,user:created?.[0]});
    }
    if(action==='admin_change_key'){
      if(!adminOk(body.adminKey)) return json(403,{ok:false,message:'Kunci Admin salah.'});
      const newKey=String(body.newKey||'');
      if(newKey.length<6) return json(400,{ok:false,message:'Kunci baru minimal 6 karakter.'});
      return json(400,{ok:false,message:'NAFPRO_ADMIN_KEY adalah environment variable Netlify. Ubah nilainya di Netlify, bukan dari browser.'});
    }
    return json(400,{ok:false,message:'Action tidak dikenal.'});
  }catch(e){ console.error(e); return json(500,{ok:false,message:e.message||'Server error.'}); }
};
