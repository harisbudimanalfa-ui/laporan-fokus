LAPORAN-FOKUS-v3

Perbaikan utama:
1. Login tidak lagi menggunakan tabel fokus_stores.
2. Kode toko divalidasi dari public.kode_toko dengan aktif=true.
3. User/NIK/password divalidasi dari public.naf_users.
4. Secret Supabase hanya dipakai di Netlify Function, tidak ditaruh di browser.
5. ZIP database tetap diproses lokal di browser dan divalidasi agar kode toko file cocok dengan kode toko login.
6. Countdown akses tetap tersedia.

Environment variables Netlify:
SUPABASE_URL = URL project Supabase Anda
SUPABASE_SECRET_KEY = Secret/service-role key Supabase Anda
NAFPRO_ADMIN_KEY = kunci admin Anda

Catatan password:
- Versi ini membuat password baru sebagai SHA-256 pada kolom naf_users.password_hash.
- Login juga masih menerima nilai password_hash plaintext untuk kompatibilitas data lama.
