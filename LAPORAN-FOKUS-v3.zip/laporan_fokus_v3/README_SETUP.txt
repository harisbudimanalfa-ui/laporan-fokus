LAPORAN-FOKUS-v3

Perbaikan utama:
1. Login Kode Toko sekarang memeriksa tabel Supabase `kode_toko`.
2. Tidak lagi menggunakan tabel `fokus_stores`.
3. Validasi dilakukan server-side melalui Netlify Function agar secret key tidak masuk ke browser.
4. File ZIP tetap divalidasi agar kode toko pada file sesuai dengan kode toko yang login.

Netlify Environment Variables:
- SUPABASE_URL = URL project Supabase
- SUPABASE_SECRET_KEY = Secret/Service Role key Supabase

Deploy:
Upload isi ZIP ke GitHub lalu hubungkan repository ke Netlify.
Pastikan Build publish directory = . dan Functions directory = netlify/functions.

Catatan schema:
Tabel wajib bernama `kode_toko` dan memiliki kolom `kode_toko`.
Kolom `active`/`aktif` atau `status` bersifat opsional. Jika tidak ada, kode dianggap aktif.
