const {createClient}=require('@supabase/supabase-js');
const db=createClient(process.env.SUPABASE_URL,process.env.SUPABASE_SERVICE_ROLE_KEY);
const indicators=['PSM','PWP','SERBA GRATIS','SUEGGER','CEBAN','NEW MEMBER','KONTRIBUSI MEMBER'];
const json=(s,b)=>({statusCode:s,headers:{'content-type':'application/json','access-control-allow-origin':'*'},body:JSON.stringify(b)});
const admin=e=>(e.headers?.['x-admin-key']||e.headers?.['X-Admin-Key'])===process.env.ADMIN_KEY;

exports.handler=async e=>{
 try{
  const q=e.queryStringParameters||{};
  if(e.httpMethod==='GET'&&q.action==='store-check'){
   const store=String(q.store||'').trim().toUpperCase();
   if(!store)return json(400,{error:'Kode toko wajib diisi'});
   const {data,error}=await db.from('fokus_stores').select('store,active').eq('store',store).eq('active',true).maybeSingle();
   if(error)throw error;
   return data?json(200,{allowed:true}):json(403,{allowed:false,error:'Kode toko tidak terdaftar atau tidak aktif'});
  }
  if(e.httpMethod==='GET'&&q.action==='report'){
   const store=String(q.store||'').trim().toUpperCase(),period=String(q.period||'').trim();
   if(!store||!period)return json(400,{error:'Parameter tidak lengkap'});
   const check=await db.from('fokus_stores').select('store').eq('store',store).eq('active',true).maybeSingle();
   if(!check.data)return json(403,{error:'Kode toko tidak valid'});
   const {data,error}=await db.from('fokus_metrics').select('indicator,target,actual').eq('store',store).eq('period',period);
   if(error)throw error;return json(200,{data:data||[]});
  }
  if(e.httpMethod==='POST'){
   let body=JSON.parse(e.body||'[]');if(!Array.isArray(body))body=[body];
   if(!body.length)return json(400,{error:'Tidak ada data'});
   const store=String(body[0].store||'').trim().toUpperCase(),period=String(body[0].period||'').trim();
   if(!store||!period)return json(400,{error:'Data tidak lengkap'});
   if(body.some(x=>String(x.store||'').trim().toUpperCase()!==store||String(x.period||'').trim()!==period||!indicators.includes(String(x.indicator||'').trim().toUpperCase())))
     return json(400,{error:'Data tidak valid'});
   const check=await db.from('fokus_stores').select('store').eq('store',store).eq('active',true).maybeSingle();
   if(!check.data)return json(403,{error:'Kode toko tidak valid'});
   const rows=body.map(x=>({store,period,indicator:String(x.indicator).trim().toUpperCase(),target:Number(x.target||0),actual:Number(x.actual||0),updated_at:new Date().toISOString()}));
   const {error}=await db.from('fokus_metrics').upsert(rows,{onConflict:'store,period,indicator'});
   if(error)throw error;return json(200,{message:'Laporan berhasil disimpan'});
  }
  if(e.httpMethod==='GET'&&q.action==='admin-check')return admin(e)?json(200,{ok:true}):json(401,{error:'ADMIN_KEY tidak valid'});
  if(e.httpMethod==='GET'&&q.action==='admin-data'){
   if(!admin(e))return json(401,{error:'ADMIN_KEY tidak valid'});
   const {data,error}=await db.from('fokus_metrics').select('store,period,indicator,target,actual').order('store').order('period');
   if(error)throw error;return json(200,{data:data||[]});
  }
  return json(404,{error:'Endpoint tidak ditemukan'});
 }catch(err){return json(500,{error:err.message||'Server error'})}
};